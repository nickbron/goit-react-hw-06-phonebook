import { useState, useEffect } from 'react';
import shortid from 'shortid';
import ContactForm from 'Componets/ContactForm/ContactForm';
import ContactList from 'Componets/ContactList/ContactList';
import Filter from 'Componets/Filter/Filter';
import { Card } from './App.styled';

export default function App() {
  return (
    <Card>
      <h1 className="title">Phonebook</h1>

      <ContactForm />

      <h2 className="title">Contacts</h2>

      <Filter />

      <ContactList />
    </Card>
  );
}
