import styled from '@emotion/styled';

export const Card = styled.div`
  width: 400px;
  padding: 20px;
  margin: 20px;
  border: 1px solid black;
`;
